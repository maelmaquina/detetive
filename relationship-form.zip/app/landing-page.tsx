"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Search, Shield, Heart, Star, CheckCircle, AlertTriangle, Lock, Mail } from "lucide-react"

export default function LandingPage() {
  const [currentStep, setCurrentStep] = useState<"landing" | "form" | "questions" | "analysis" | "checkout">("landing")
  const [formData, setFormData] = useState({
    userName: "",
    partnerName: "",
    answers: [] as string[],
  })

  const [showVerificationPopup, setShowVerificationPopup] = useState(false)
  const [verificationProgress, setVerificationProgress] = useState(0)
  const [currentVerification, setCurrentVerification] = useState("")

  const [showFinalAlertPopup, setShowFinalAlertPopup] = useState(false)
  const [finalAlertProgress, setFinalAlertProgress] = useState(0)

  const [showFinalCheckoutPopup, setShowFinalCheckoutPopup] = useState(false)

  const questions = [
    "Ele(a) começou a esconder o celular de você?",
    "Você percebeu mudanças na rotina dele(a)?",
    "Ele(a) já apagou mensagens de WhatsApp ou redes sociais?",
    "Você já percebeu que ele(a) mudou a senha ou bloqueio do celular?",
    "Vocês brigam mais que antes sem motivo claro?",
    "Ele(a) ficou mais distante ou menos carinhoso(a) ultimamente?",
    "Algum(a) amigo(a) já deu indiretas ou avisou algo estranho?",
    "Você sente no seu coração que tem algo errado?",
  ]

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.userName && formData.partnerName) {
      setCurrentStep("questions")
    }
  }

  const handleAnswer = (answer: string) => {
    const newAnswers = [...formData.answers, answer]
    setFormData((prev) => ({ ...prev, answers: newAnswers }))

    if (formData.answers.length < questions.length - 1) {
      // Continue para próxima pergunta
    } else {
      // Mostrar popup de verificação
      setShowVerificationPopup(true)
      startVerificationProcess()
    }
  }

  const startVerificationProcess = () => {
    const verificationSteps = [
      "🔍 Conectando aos servidores...",
      "📱 Acessando dados do WhatsApp...",
      "⚠️ Detectando atividade suspeita...",
      "💕 Verificando perfil no Tinder...",
      "🚨 ALERTA: Conversas ocultas encontradas",
      "📷 Analisando fotos do Instagram...",
      "✅ Análise completa",
    ]

    let step = 0
    let progress = 0

    const interval = setInterval(() => {
      if (step < verificationSteps.length) {
        setCurrentVerification(verificationSteps[step])
        step++
      }

      progress += 100 / 7
      setVerificationProgress(Math.min(progress, 100))

      if (progress >= 100) {
        clearInterval(interval)
        setTimeout(() => {
          setShowVerificationPopup(false)
          setShowFinalAlertPopup(true)
          startFinalAlertProcess()
        }, 1000)
      }
    }, 1000)
  }

  const startFinalAlertProcess = () => {
    let progress = 0

    const interval = setInterval(() => {
      progress += 100 / 6
      setFinalAlertProgress(Math.min(progress, 100))

      if (progress >= 100) {
        clearInterval(interval)
        setTimeout(() => {
          setShowFinalAlertPopup(false)
          setCurrentStep("checkout")
        }, 500)
      }
    }, 1000)
  }

  const scrollToForm = () => {
    setCurrentStep("form")
  }

  const handleCheckoutClick = () => {
    setShowFinalCheckoutPopup(true)
  }

  const handleAcceptTerms = () => {
    window.open("https://link.zyonpay.com/YtkFKWkeAW", "_blank")
  }

  const alertSignals = formData.answers.filter((answer) => answer === "sim").length

  return (
    <div className="min-h-screen bg-white">
      {/* Landing Page */}
      {currentStep === "landing" && (
        <>
          <section className="bg-gradient-to-br from-red-50 to-red-100 py-16 px-4">
            <div className="max-w-4xl mx-auto text-center">
              <Badge className="bg-red-600 text-white px-4 py-2 text-sm font-medium mb-4">
                🚨 ALERTA DE RELACIONAMENTO
              </Badge>

              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                ⚠️ Desconfia de traição?
                <br />
                <span className="text-red-600">Descubra a verdade agora</span>
              </h1>

              <p className="text-xl md:text-2xl text-gray-700 mb-8 max-w-3xl mx-auto leading-relaxed">
                Responda 8 perguntas rápidas e receba um <strong>relatório confidencial</strong> com sinais de alerta.
                <span className="text-red-600 font-semibold"> Entrega imediata, 100% sigiloso.</span>
              </p>

              <Button
                onClick={scrollToForm}
                size="lg"
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 text-xl font-bold rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                🔓 Quero desbloquear meu relatório agora
              </Button>

              <div className="mt-6 flex items-center justify-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Resultado em 2 minutos</span>
                </div>
                <div className="flex items-center gap-1">
                  <Shield className="h-4 w-4 text-green-600" />
                  <span>100% Confidencial</span>
                </div>
              </div>
            </div>
          </section>

          <section className="py-16 px-4 bg-white">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-12">
                Por que milhares confiam no nosso método?
              </h2>

              <div className="grid md:grid-cols-3 gap-8">
                <Card className="text-center p-6 border-2 hover:border-red-200 transition-all duration-300">
                  <CardContent className="pt-6">
                    <div className="mx-auto mb-4 p-3 bg-red-100 rounded-full w-fit">
                      <Shield className="h-8 w-8 text-red-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">100% Anônimo</h3>
                    <p className="text-gray-600">Seus dados são protegidos e o relatório é totalmente confidencial.</p>
                  </CardContent>
                </Card>

                <Card className="text-center p-6 border-2 hover:border-red-200 transition-all duration-300">
                  <CardContent className="pt-6">
                    <div className="mx-auto mb-4 p-3 bg-red-100 rounded-full w-fit">
                      <Search className="h-8 w-8 text-red-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">Relatório Imediato</h3>
                    <p className="text-gray-600">Receba seu relatório personalizado em menos de 2 minutos.</p>
                  </CardContent>
                </Card>

                <Card className="text-center p-6 border-2 hover:border-red-200 transition-all duration-300">
                  <CardContent className="pt-6">
                    <div className="mx-auto mb-4 p-3 bg-red-100 rounded-full w-fit">
                      <Heart className="h-8 w-8 text-red-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">Baseado em Psicologia</h3>
                    <p className="text-gray-600">Desenvolvido por especialistas em relacionamentos.</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </section>
        </>
      )}

      {/* Form Section */}
      {currentStep === "form" && (
        <section className="py-16 px-4 bg-white">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">🕵️ Vamos começar</h2>
              <p className="text-xl text-gray-600">Primeiro, precisamos de algumas informações básicas</p>
            </div>

            <Card className="p-8 shadow-xl border-2 border-red-100">
              <CardContent>
                <form onSubmit={handleFormSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="userName" className="text-lg font-medium">
                        👤 Seu nome
                      </Label>
                      <Input
                        id="userName"
                        type="text"
                        placeholder="Digite seu nome"
                        value={formData.userName}
                        onChange={(e) => handleInputChange("userName", e.target.value)}
                        className="p-3 text-lg"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="partnerName" className="text-lg font-medium">
                        💕 Nome do(a) parceiro(a)
                      </Label>
                      <Input
                        id="partnerName"
                        type="text"
                        placeholder="Nome do(a) parceiro(a)"
                        value={formData.partnerName}
                        onChange={(e) => handleInputChange("partnerName", e.target.value)}
                        className="p-3 text-lg"
                        required
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full bg-red-600 hover:bg-red-700 text-white py-4 text-xl font-bold rounded-lg shadow-lg"
                  >
                    🔓 Gerar meu relatório agora
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Questions Section */}
      {currentStep === "questions" && (
        <section className="py-16 px-4 bg-gradient-to-br from-red-50 to-pink-50 min-h-screen">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <Badge className="bg-red-600 text-white px-4 py-2 text-sm font-medium mb-4">
                Pergunta {formData.answers.length + 1} de {questions.length}
              </Badge>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
                <div
                  className="bg-red-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(formData.answers.length / questions.length) * 100}%` }}
                ></div>
              </div>
            </div>

            <Card className="p-8 shadow-xl border-2 border-red-100">
              <CardContent>
                <div className="text-center mb-8">
                  <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">
                    {questions[formData.answers.length]}
                  </h2>
                </div>

                <div className="space-y-4">
                  <Button
                    onClick={() => handleAnswer("sim")}
                    size="lg"
                    className="w-full bg-red-600 hover:bg-red-700 text-white py-4 text-xl font-bold rounded-lg shadow-lg"
                  >
                    ✅ Sim
                  </Button>

                  <Button
                    onClick={() => handleAnswer("nao")}
                    variant="outline"
                    size="lg"
                    className="w-full border-2 border-gray-300 text-gray-700 hover:bg-gray-50 py-4 text-xl font-bold rounded-lg"
                  >
                    ❌ Não
                  </Button>
                </div>

                <div className="mt-6 text-center text-sm text-gray-500">
                  Analisando o comportamento de {formData.partnerName}...
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Checkout Section */}
      {currentStep === "checkout" && (
        <section className="py-16 px-4 bg-gradient-to-br from-gray-50 to-red-50 min-h-screen">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <Badge className="bg-red-600 text-white px-4 py-2 text-sm font-medium mb-4 animate-pulse">
                🔍 ANÁLISE FINALIZADA
              </Badge>
            </div>

            <Card className="p-8 shadow-2xl border-2 border-red-200 bg-white">
              <CardContent>
                <div className="space-y-6">
                  <div className="text-center">
                    <AlertTriangle className="h-16 w-16 mx-auto mb-4 text-red-600" />
                    <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
                      Identificamos comportamentos suspeitos no relacionamento com{" "}
                      <span className="text-red-600">{formData.partnerName}</span>.
                    </h2>
                    <p className="text-xl text-gray-700 mb-6">Você está a um clique de descobrir a verdade.</p>
                  </div>

                  <div className="text-center bg-gradient-to-r from-red-600 to-pink-600 text-white p-6 rounded-lg">
                    <h3 className="text-2xl font-bold mb-2">Por apenas R$19,90</h3>
                    <p className="text-lg mb-4">É menos do que um lanche. Mas pode te livrar de uma grande decepção.</p>
                  </div>

                  <div className="text-center space-y-4">
                    <Button
                      onClick={handleCheckoutClick}
                      size="lg"
                      className="w-full bg-red-600 hover:bg-red-700 text-white py-6 text-2xl font-bold rounded-lg shadow-xl animate-pulse"
                    >
                      🔓 Ver Relatório Agora — R$19,90
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Verification Popup */}
      {showVerificationPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-lg bg-white">
            <CardContent className="p-8 text-center">
              <div className="mb-6">
                <div className="animate-spin mx-auto mb-4 p-4 bg-gradient-to-r from-red-500 to-pink-500 rounded-full w-fit">
                  <Search className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">🔎 ANÁLISE EM ANDAMENTO</h3>
                <p className="text-gray-600">
                  Investigando atividade digital de <strong className="text-red-600">{formData.partnerName}</strong>
                </p>
              </div>

              <div className="space-y-4">
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div
                    className="bg-gradient-to-r from-red-500 to-pink-500 h-4 rounded-full transition-all duration-1000"
                    style={{ width: `${verificationProgress}%` }}
                  ></div>
                </div>

                <div className="bg-gray-900 text-green-400 p-4 rounded-lg min-h-[80px] flex items-center justify-center font-mono text-sm">
                  <p>{currentVerification}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Final Alert Popup */}
      {showFinalAlertPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-white border-4 border-red-500">
            <CardContent className="p-6 text-center">
              <div className="mb-4">
                <div className="mx-auto mb-4 p-3 bg-red-100 rounded-full w-fit animate-bounce">
                  <AlertTriangle className="h-12 w-12 text-red-600" />
                </div>

                <h3 className="text-xl font-bold text-red-600 mb-2 animate-pulse">🚨 ALERTA CRÍTICO DETECTADO</h3>

                <p className="text-gray-800 font-semibold mb-3">
                  Encontramos conversas suspeitas no WhatsApp e Instagram de{" "}
                  <span className="text-red-600">{formData.partnerName}</span>
                </p>

                <div className="bg-red-50 p-3 rounded-lg mb-4">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-red-700">
                      <span className="text-lg">💬</span>
                      <span className="font-medium">3 conversas ocultas no WhatsApp</span>
                    </div>
                    <div className="flex items-center gap-2 text-red-700">
                      <span className="text-lg">📷</span>
                      <span className="font-medium">Mensagens privadas no Instagram</span>
                    </div>
                    <div className="flex items-center gap-2 text-red-700">
                      <span className="text-lg">🕐</span>
                      <span className="font-medium">Atividade suspeita após 22h</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-red-500 to-red-700 h-3 rounded-full transition-all duration-1000"
                  style={{ width: `${finalAlertProgress}%` }}
                ></div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Final Checkout Popup */}
      {showFinalCheckoutPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-2xl bg-white border-2 border-green-500 max-h-[90vh] overflow-y-auto">
            <CardContent className="p-4 sm:p-8">
              <div className="text-center mb-6">
                <div className="mx-auto mb-4 p-4 bg-green-100 rounded-full w-fit">
                  <Shield className="h-12 w-12 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">🔒 Entrega Segura do Relatório</h3>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <Mail className="h-5 w-5 text-green-600" />
                        <div>
                          <p className="font-semibold text-gray-900">Entrega via E-mail</p>
                          <p className="text-sm text-gray-700">Relatório enviado em até 5 minutos</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Shield className="h-5 w-5 text-green-600" />
                        <div>
                          <p className="font-semibold text-gray-900">100% Sigiloso</p>
                          <p className="text-sm text-gray-700">Dados criptografados e protegidos</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Lock className="h-5 w-5 text-green-600" />
                        <div>
                          <p className="font-semibold text-gray-900">Dados Seguros</p>
                          <p className="text-sm text-gray-700">Não compartilhamos com terceiros</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                    <div className="flex items-start gap-3">
                      <Mail className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-blue-900 mb-1">📧 Importante:</p>
                        <p className="text-sm text-blue-800">
                          Verifique sua caixa de entrada e spam. O relatório chegará com o assunto:
                        </p>
                        <p className="text-sm font-medium text-blue-900 mt-1">
                          "Relatório Confidencial - {formData.partnerName}"
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-center justify-center">
                  <div className="bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg p-6 w-full max-w-sm">
                    <div className="bg-white rounded-lg shadow-lg p-4 mb-4">
                      <div className="flex items-center gap-2 mb-3">
                        <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                          <Mail className="h-4 w-4 text-red-600" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-gray-900">Relatório Confidencial</p>
                          <p className="text-xs text-gray-500">Detetive Digital</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="h-2 bg-gray-200 rounded w-full"></div>
                        <div className="h-2 bg-gray-200 rounded w-3/4"></div>
                        <div className="h-2 bg-red-200 rounded w-1/2"></div>
                      </div>
                    </div>

                    <div className="text-center">
                      <div className="inline-flex items-center gap-2 bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                        <CheckCircle className="h-4 w-4" />
                        <span>Entrega Garantida</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 text-center">
                    <div className="flex justify-center items-center gap-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-sm text-gray-600">Mais de 50.000 relatórios entregues</p>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg mb-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm text-yellow-800">
                      <strong>Termos de Segurança:</strong> Ao continuar, você aceita nossos termos de privacidade.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <Button
                  onClick={handleAcceptTerms}
                  size="lg"
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-4 text-xl font-bold rounded-lg shadow-lg"
                >
                  ✅ Aceito os Termos - Finalizar Pagamento
                </Button>

                <Button
                  onClick={() => setShowFinalCheckoutPopup(false)}
                  variant="outline"
                  className="w-full border-gray-300 text-gray-600 hover:bg-gray-50 py-3"
                >
                  ❌ Cancelar
                </Button>
              </div>

              <div className="mt-4 text-center">
                <p className="text-xs text-gray-500">🔒 Pagamento 100% seguro • SSL Certificado</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
